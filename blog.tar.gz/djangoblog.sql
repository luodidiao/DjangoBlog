-- MySQL dump 10.14  Distrib 5.5.60-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: djangoblog
-- ------------------------------------------------------
-- Server version	5.5.60-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_bloguser`
--

DROP TABLE IF EXISTS `accounts_bloguser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_bloguser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `mugshot` varchar(100) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_bloguser`
--

LOCK TABLES `accounts_bloguser` WRITE;
/*!40000 ALTER TABLE `accounts_bloguser` DISABLE KEYS */;
INSERT INTO `accounts_bloguser` VALUES (1,'luodidiao522527','2019-04-12 01:29:00.000000',1,'luodidiao','','','473145009@qq.com',1,1,'2019-04-10 12:46:00.000000','','','2019-04-10 12:46:00.000000','2019-04-10 12:46:00.000000'),(3,'pbkdf2_sha256$120000$8vz7M7E7yL3w$MeyitEzIgMqLhNgmw6hZ3RRG9xwRcBzhbeNZFs01c8o=','2019-04-16 07:32:12.808784',1,'admin','','','admin@qq.com',1,1,'2019-04-12 11:39:46.521142','','','2019-04-12 11:39:46.521176','2019-04-12 11:39:46.521185');
/*!40000 ALTER TABLE `accounts_bloguser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_bloguser_groups`
--

DROP TABLE IF EXISTS `accounts_bloguser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_bloguser_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloguser_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_bloguser_groups_bloguser_id_group_id_fc37e89b_uniq` (`bloguser_id`,`group_id`),
  KEY `accounts_bloguser_groups_group_id_98d76804_fk_auth_group_id` (`group_id`),
  CONSTRAINT `accounts_bloguser_groups_group_id_98d76804_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `accounts_bloguser_gr_bloguser_id_a16ccbb7_fk_accounts_` FOREIGN KEY (`bloguser_id`) REFERENCES `accounts_bloguser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_bloguser_groups`
--

LOCK TABLES `accounts_bloguser_groups` WRITE;
/*!40000 ALTER TABLE `accounts_bloguser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_bloguser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_bloguser_user_permissions`
--

DROP TABLE IF EXISTS `accounts_bloguser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts_bloguser_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloguser_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_bloguser_user_p_bloguser_id_permission_i_14808777_uniq` (`bloguser_id`,`permission_id`),
  KEY `accounts_bloguser_us_permission_id_ae5159b9_fk_auth_perm` (`permission_id`),
  CONSTRAINT `accounts_bloguser_us_bloguser_id_7e1b5742_fk_accounts_` FOREIGN KEY (`bloguser_id`) REFERENCES `accounts_bloguser` (`id`),
  CONSTRAINT `accounts_bloguser_us_permission_id_ae5159b9_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_bloguser_user_permissions`
--

LOCK TABLES `accounts_bloguser_user_permissions` WRITE;
/*!40000 ALTER TABLE `accounts_bloguser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_bloguser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add group',2,'add_group'),(6,'Can change group',2,'change_group'),(7,'Can delete group',2,'delete_group'),(8,'Can view group',2,'view_group'),(9,'Can add permission',3,'add_permission'),(10,'Can change permission',3,'change_permission'),(11,'Can delete permission',3,'delete_permission'),(12,'Can view permission',3,'view_permission'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add site',6,'add_site'),(22,'Can change site',6,'change_site'),(23,'Can delete site',6,'delete_site'),(24,'Can view site',6,'view_site'),(25,'Can add 文章',7,'add_article'),(26,'Can change 文章',7,'change_article'),(27,'Can delete 文章',7,'delete_article'),(28,'Can view 文章',7,'view_article'),(29,'Can add 分类',8,'add_category'),(30,'Can change 分类',8,'change_category'),(31,'Can delete 分类',8,'delete_category'),(32,'Can view 分类',8,'view_category'),(33,'Can add 标签',9,'add_tag'),(34,'Can change 标签',9,'change_tag'),(35,'Can delete 标签',9,'delete_tag'),(36,'Can view 标签',9,'view_tag'),(37,'Can add 友情链接',10,'add_links'),(38,'Can change 友情链接',10,'change_links'),(39,'Can delete 友情链接',10,'delete_links'),(40,'Can view 友情链接',10,'view_links'),(41,'Can add 网站配置',11,'add_blogsettings'),(42,'Can change 网站配置',11,'change_blogsettings'),(43,'Can delete 网站配置',11,'delete_blogsettings'),(44,'Can view 网站配置',11,'view_blogsettings'),(45,'Can add 侧边栏',12,'add_sidebar'),(46,'Can change 侧边栏',12,'change_sidebar'),(47,'Can delete 侧边栏',12,'delete_sidebar'),(48,'Can view 侧边栏',12,'view_sidebar'),(49,'Can add user',13,'add_bloguser'),(50,'Can change user',13,'change_bloguser'),(51,'Can delete user',13,'delete_bloguser'),(52,'Can view user',13,'view_bloguser'),(53,'Can add 评论',14,'add_comment'),(54,'Can change 评论',14,'change_comment'),(55,'Can delete 评论',14,'delete_comment'),(56,'Can view 评论',14,'view_comment'),(57,'Can add oauth用户',15,'add_oauthuser'),(58,'Can change oauth用户',15,'change_oauthuser'),(59,'Can delete oauth用户',15,'delete_oauthuser'),(60,'Can view oauth用户',15,'view_oauthuser'),(61,'Can add oauth配置',16,'add_oauthconfig'),(62,'Can change oauth配置',16,'change_oauthconfig'),(63,'Can delete oauth配置',16,'delete_oauthconfig'),(64,'Can view oauth配置',16,'view_oauthconfig'),(65,'Can add 命令',17,'add_commands'),(66,'Can change 命令',17,'change_commands'),(67,'Can delete 命令',17,'delete_commands'),(68,'Can view 命令',17,'view_commands'),(69,'Can add 邮件发送log',18,'add_emailsendlog'),(70,'Can change 邮件发送log',18,'change_emailsendlog'),(71,'Can delete 邮件发送log',18,'delete_emailsendlog'),(72,'Can view 邮件发送log',18,'view_emailsendlog'),(73,'Can add OwnTrackLogs',19,'add_owntracklog'),(74,'Can change OwnTrackLogs',19,'change_owntracklog'),(75,'Can delete OwnTrackLogs',19,'delete_owntracklog'),(76,'Can view OwnTrackLogs',19,'view_owntracklog');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_article`
--

DROP TABLE IF EXISTS `blog_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  `title` varchar(200) NOT NULL,
  `body` longtext NOT NULL,
  `pub_time` datetime(6) DEFAULT NULL,
  `status` varchar(1) NOT NULL,
  `comment_status` varchar(1) NOT NULL,
  `type` varchar(1) NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `article_order` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `blog_article_author_id_905add38_fk_accounts_bloguser_id` (`author_id`),
  KEY `blog_article_category_id_7e38f15e_fk_blog_category_id` (`category_id`),
  CONSTRAINT `blog_article_author_id_905add38_fk_accounts_bloguser_id` FOREIGN KEY (`author_id`) REFERENCES `accounts_bloguser` (`id`),
  CONSTRAINT `blog_article_category_id_7e38f15e_fk_blog_category_id` FOREIGN KEY (`category_id`) REFERENCES `blog_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_article`
--

LOCK TABLES `blog_article` WRITE;
/*!40000 ALTER TABLE `blog_article` DISABLE KEYS */;
INSERT INTO `blog_article` VALUES (1,'2019-04-10 14:03:34.634677','2019-04-10 14:03:34.634692','rsync＋inotify实时数据同步','> 1，rsync命令用法\r\n\r\n    格式：rsync [选项..] 源目录 目标目录\r\n    区别:同步与复制的差异\r\n    复制:完全拷贝源到目标\r\n    同步:增量拷贝,只传输变化过的数据\r\n\r\n> ２，本地同步\r\n\r\n    rsync [选项..] 本地目录1 本地目录2 #把目录1同步到目录2下\r\n    rsync [选项..] 本地目录1/ 本地目录2 #把目录1下的数据同步到目录2下\r\n    -a :归档模式，相当于-rlptgoD\r\n    -v :显示详细信息\r\n    -z :传输过程中启用压缩/解压\r\n    -n :测试同步过程，不做实际修改 #与-avz连用\r\n    --delete :删除目标文件夹内多余的文档 #与-avz连用\r\n\r\n> 3，远程同步\r\n\r\n    rsync+ssh\r\n    --命令\r\n    rsync user@host:远程目录/ #列出ssh服务端资源\r\n    rsync [选项..] user@host:远程目录 本地目录 #下行（下载） 不常用\r\n    rsync [选项..] 本地目录 user@host:远程目录 #上行（上传） 常用\r\n    -a :归档模式，相当于-rlptgoD\r\n    -v :显示详细信息\r\n    -z :传输过程中启用压缩/解压\r\n    -n :测试同步过程，不做实际修改 #与-avz连用\r\n    --delete :删除目标文件夹内多余的文档 #与-avz连用\r\n    提示：同步目录时在目录后加/，表示同步目录里的数据；同步目录不加/，表示同步此目录。\r\n\r\n> 4，实现实时同步\r\n\r\n1)部署公钥、私钥，实现ssh无密码验证\r\n\r\n    [root@svr7 /]# ssh-keygen #虚拟机A生成公钥、私钥 一路回车\r\n    [root@svr7 /]# ls /root/.ssh #公钥、私钥生成的位置 \r\n    id_rsa id_rsa.pub known_hosts \r\n    [root@svr7 /]# ssh-copy-id root@192.168.4.207 #传递公钥到目标主机（入虚拟机B）\r\n    [root@pc207 ~]# ls /root/.ssh #查看上传到虚拟机B的公钥\r\n    authorized_keys #上传到客户机的公钥文件\r\n\r\n2)inotify实时同步\r\n\r\n    --源码安装inotify-tools工具，实现监控目录内容的变化\r\n\r\n    [root@svr7 /]# mkdir /myrpm \r\n    [root@svr7 /]# tar -xf /tools/inotify-tools-3.13.tar.gz -C /myrpm #减压\r\n    [root@svr7 /]# yum -y install gcc make #安装编译环境gcc make\r\n    [root@svr7 /]# cd /myrpm/inotify-tools-3.13/\r\n    [root@svr7 inotify-tools-3.13]# ./configure #生成Makefile文件\r\n    [root@svr7 inotify-tools-3.13]# make #编译成二进制文件\r\n    [root@svr7 inotify-tools-3.13]# make install #安装\r\n    [root@svr7 inotify-tools-3.13]# which inotifywait #查看命令位置\r\n    /usr/local/bin/inotifywait\r\n\r\n    --inotifywait基本用法\r\n    inotifywait [选项] 目标文件夹\r\n    -m :持续监控（捕获一个事件后不退出）\r\n    -r :递归监控，包括子目录及文件\r\n    -q :减少屏幕输出信息\r\n    -qq:无屏幕输出信息\r\n    -e :指定监控的modify move create delete attrib等事件类别\r\n\r\n３）书写shell 脚本\r\n\r\n    --利用while循环来实现反复检查单次监控\r\n    语法：\r\n    while [ 条件 ]\r\n    do\r\n    循环执行\r\n    done\r\n    \r\n    --实现\r\n\r\n    ＃vim /jluocc/rsync.sh\r\n    #/bin/bash\r\n    while inotifywait -rqq /opt\r\n    do\r\n    rsync -az --delete /opt/ root@192.168.4.207:/opt #同步本地opt目录下的数据到另一台主机的/opt目录下\r\n    done\r\n    ＃chmod +x /jluocc/rysnc.sh #给脚本执行权限\r\n    #/jluocc/rsync.sh #运行脚本达到实时数据同步\r\n\r\n４）实现开机运行数据同步脚本\r\n\r\n    #vim /etc/rc.local #打开系统开机默认运行文件\r\n    /jluocc/rsync.sh #在文件里写入刚才写的脚本的绝对路径\r\n    #chmod +x /etc/rc.local #rc.local默认没有执行权限，需要赋予执行权限\r\n\r\n> ５，总结\r\n\r\nrsync:实现数据同步\r\ninotifywait:实现监控指定目录下的数据变化，发生变化返回相应结果\r\nshell脚本:实现inotifywait实时监控，一旦数据变化，将实现rsync数据同步，达到数据的实时同步','2018-12-08 14:02:00.000000','p','o','a',417,0,1,1),(2,'2019-04-10 14:14:41.258144','2019-04-10 14:14:41.258160','nginx性能优化--第一节','> １，自定义报错页面\r\n\r\n１）配置\r\n\r\n    [root@proxy ~]# vim /usr/local/nginx/conf/nginx.conf\r\n    .. ..\r\n    error_page 404 /404.html; //自定义错误页面\r\n    .. ..\r\n    [root@proxy ~]# vim /usr/local/nginx/html/40x.html //生成错误页面\r\n    Oops,No NO no page …\r\n    [root@proxy ~]# nginx -s reload\r\n\r\n２）测试\r\n\r\n    [root@client ~]# firefox http://192.168.4.5/xxxxx //访问一个不存在的页面\r\n\r\n> ２，查看服务器状态信息\r\n\r\n1）编译安装时使用--with-http_stub_status_module开启状态页面模块\r\n\r\n    [root@proxy ~]# yum -y install gcc pcre-devel openssl-devel //安装常见依赖包\r\n    [root@proxy ~]# tar -zxvf nginx-1.12.2.tar.gz\r\n    [root@proxy ~]# cd nginx-1.12.2\r\n    [root@proxy nginx-1.12.2]# ./configure \\\r\n\r\n    --with-http_ssl_module //开启SSL加密功能\r\n    --with-stream //开启TCP/UDP代理模块\r\n    --with-http_stub_status_module //开启status状态页面\r\n    [root@proxy nginx-1.12.2]# make && make install //编译并安装\r\n\r\n２）修改配置文件\r\n\r\n    [root@proxy ~]# vim /usr/local/nginx/conf/nginx.conf\r\n    … …\r\n    location /status {　　　　　　　　　＃设置在根下输入status就可以查看nginx状态信息\r\n    stub_status on; #开启状态页面\r\n    ＃ allow IP地址;\r\n    ＃ deny IP地址(all);\r\n    }\r\n    … …\r\n    [root@proxy ~]# /usr/local/sbin/nginx #开启nginx\r\n\r\n３）查看nginx状态信息\r\n\r\n    [root@proxy ~]#firefox http://192.168.4.5/status\r\n    Active connections: 1 \r\n    server accepts handled requests\r\n    10 10 3 \r\n    Reading: 0 Writing: 1 Waiting: 0\r\n    Active connections：当前活动的连接数量。\r\n    Accepts：已经接受客户端的连接总数量。\r\n    Handled：已经处理客户端的连接总数量。\r\n    （一般与accepts一致，除非服务器限制了连接数量）。\r\n    Requests：客户端发送的请求数量。\r\n    Reading：当前服务器正在读取客户端请求头的数量。\r\n    Writing：当前服务器正在写响应信息的数量。\r\n    Waiting：当前多少客户端在等待服务器的响应。\r\n\r\n> 3，优化nginx并发量\r\n\r\n1）优化前使用ab高并发测试\r\n\r\n    [root@proxy ~]# ab -n 2000 -c 2000 http://192.168.4.5/\r\n    Benchmarking 192.168.4.5 (be patient)\r\n    socket: Too many open files (24) //提示打开文件数量过多\r\n\r\n２）修改Nginx配置文件，增加并发量\r\n\r\n    [root@proxy ~]# vim /usr/local/nginx/conf/nginx.conf\r\n    .. ..\r\n    worker_processes 2; //设置进程数，与CPU核心数量一致　　　　　　\r\n    events {\r\n    worker_connections 65535; //每个worker最大并发连接数,尽量写大一点\r\n    use epoll;\r\n    }\r\n    .. ..\r\n    [root@proxy ~]# nginx -s reload　　　　//刷新配置文件\r\n\r\n３）优化linux内核参数(最大文件数量)\r\n\r\n    [root@proxy ~]#ulimit -a //查看所有属性值\r\n    [root@proxy ~]#ulimit -Hn 100000 //设置硬限制（临时规则）\r\n    [root@proxy ~]#ulimit -Sn 100000 //设置软限制（临时规则）\r\n    [root@proxy ~]#vim /etc/security/limits.conf #修改配置文件．永久设置\r\n    .. .. \r\n    　＊ 　 hard nofile 100000　\r\n    　＊ 　 soft nofile 100000\r\n\r\n4）优化后测试服务器并发量（因为客户端没调内核参数，所以在proxy测试）\r\n\r\n    [root@proxy ~]# ab -n 2000 -c 2000 http://192.168.4.5/　　　＃正常显示页面\r\n\r\n> 4，优化Nginx数据包头缓存\r\n\r\n1）优化前，使用脚本测试长头部请求是否能获得响应\r\n\r\n    [root@proxy ~]# cat lnmp_soft/buffer.sh \r\n    #!/bin/bash\r\n    URL=http://192.168.4.5/index.html?\r\n    for i in {1..5000}\r\n    do\r\n    URL=${URL}v$i=$i\r\n    done\r\n    curl $URL //经过5000次循环后，生成一个长的URL地址栏\r\n    [root@proxy ~]# ./buffer.sh\r\n    .. ..\r\n    <center><h1>414 Request-URI Too Large</h1></center> //提示头部信息过大\r\n\r\n２）修改Nginx配置文件，增加数据包头部缓存大小\r\n\r\n    [root@proxy ~]# vim /usr/local/nginx/conf/nginx.conf\r\n    .. ..\r\n    http {\r\n    　　client_header_buffer_size 1k; //默认请求包头信息的缓存\r\n    　 large_client_header_buffers 4 1m; //大请求包头部信息的缓存个数与容量,生产环境设置　4　4k 　就够用了　\r\n    .. ..\r\n    }\r\n    [root@proxy ~]# nginx -s reload\r\n\r\n3）优化后，使用脚本测试长头部请求是否能获得响应\r\n\r\n    [root@proxy ~]#cat cat buffer.sh \r\n    #!/bin/bash\r\n    URL=http://192.168.4.5/index.html?\r\n    for i in {1..5000}\r\n    do\r\n    URL=${URL}v$i=$i\r\n    done\r\n    curl $URL\r\n    [root@proxy ~]# ./buffer.sh\r\n\r\n> 5，设置浏览器本地缓存静态数据\r\n\r\n１）修改Nginx配置文件，定义对静态页面的缓存时间\r\n\r\n    [root@proxy ~]# vim /usr/local/nginx/conf/nginx.conf\r\n    server {\r\n    listen 80;\r\n    server_name localhost;\r\n    location / {\r\n    root html;\r\n    index index.html index.htm;\r\n    }\r\n    location ~* .(jpg|jpeg|gif|png|css|js|ico|xml)$ {\r\n    expires 30d; //定义客户端缓存时间为30天\r\n    }\r\n    }\r\n    [root@proxy ~]# cp /usr/share/backgrounds/day.jpg /usr/local/nginx/html\r\n    [root@proxy ~]# nginx -s reload\r\n\r\n2）优化后，使用Firefox浏览器访问图片，再次查看缓存信息\r\n\r\n    [root@client ~]# firefox http://192.168.4.5/day.jpg\r\n    在Firefox地址栏内输入about:cache，查看本地缓存数据，查看是否有图片以及过期时间是否正确。\r\n\r\n> 6，nginx日志切割\r\n\r\n思路：\r\n\r\n    把旧的日志重命名\r\n    2.kill USR1 PID(nginx的进程PID号)\r\n    １）手动执行\r\n    备注：/usr/local/nginx/logs/nginx.pid文件中存放的是nginx的进程PID号。\r\n    [root@proxy ~]#mv /usr/local/nginx/logs/access.log /usr/local/nginx/logs/access2.log\r\n    [root@proxy ~]#kill -USR1 $(cat /usr/local/logs/nginx.pid) #检查日志文件，重新生成access.log/error.log文件\r\n    ２）自动完成\r\n    设置每周6的03点03分自动执行脚本完成日志切割工作。\r\n    [root@proxy ~]# vim /usr/local/nginx/logbak.sh //编写脚本\r\n    ＃!/bin/bash\r\n    date=$(date +%Y%m%d)\r\n    logpath=/usr/local/nginx/logs\r\n    mv $(logpath)/access.log $(logpath)/access-$(date).log\r\n    mv $(logppath)/error.log $(logpath)/error-$(date).log\r\n    kill -USR1 $(cat $logpath/nginx.pid)\r\n    [root@proxy ~]# crontab -e #对当前用户书写计划任务（一般是管理员） \r\n    03 03 6 /usr/local/nginx/logbak.sh\r\n    7，对页面进行压缩处理\r\n    提示：对多媒体文件不要压缩，一般应用于图片，样式，js等\r\n    １）修改nginx配置文件\r\n    [root@proxy ~]# cat /usr/local/nginx/conf/nginx.conf\r\n    http {\r\n    .. ..\r\n    gzip on; //开启压缩\r\n    gzip_min_lenght 1000; //当返回内容大于此值时才会使用gzip进行压缩,以K为单位,当值为0时，所有页面都进行压缩\r\n    gzip_comp_level 4; //压缩比率（1－9），数字越高，花费时间越多，压缩效率越好，一般选中间\r\n    gzip_types text/plain text/css application/json application/x-javascript text/xml application/xml application/xml+rss text/javascript;\r\n    //对特定文件压缩，类型参考mime.types，位置：/usr/local/nginx/conf/mime.types\r\n    .. ..\r\n    }\r\n\r\n> 8，服务器内存缓存\r\n\r\n    如果需要处理大量静态文件，可以将文件缓存在内存，下次访问会更快。\r\n    ＃vim /usr/local/nginx/conf/nginc.conf\r\n    http{\r\n    open_file_cache max=2000 inactive=20s;\r\n    open_file_cache_valid 60s;\r\n    open_file_cache_min_uses 5;\r\n    open_file_cache_errors off; //关闭缓存过期报错\r\n    \r\n    //设置服务器最大缓存2000个文件句柄，关闭20秒内无请求的文件句柄\r\n    //文件句柄的有效时间是60秒，60秒后过期\r\n    //只有访问次数超过5次会被缓存\r\n    }','2018-12-11 14:14:00.000000','p','o','a',369,0,1,3),(3,'2019-04-11 14:18:48.983309','2019-04-11 14:18:48.983328','本站博客部署教程uwsgi+nginx','**一 源码下载**\r\n\r\n    [root@VM_0_2_centos ~]# yum -y install git\r\n    [root@VM_0_2_centos ~]# git clone https://github.com/luodidiao/DjangoBlog.git\r\n    [root@VM_0_2_centos ~]# cd DjangoBlog/\r\n    [root@VM_0_2_centos DjangoBlog]# vim DjangoBlog/settings.py\r\n    DATABASES = {\r\n        \'default\': {\r\n            \'ENGINE\': \'django.db.backends.mysql\',\r\n            \'NAME\': \'djangoblog\',\r\n            \'USER\': \'blog\',\r\n            \'PASSWORD\': \'password\',\r\n            \'HOST\': \'localhost\',\r\n            \'PORT\': 3306,\r\n            \'OPTIONS\': {\'charset\': \'utf8mb4\'},\r\n        }\r\n    }\r\n\r\n\r\n**二 nginx搭建**\r\n\r\n    [root@VM_0_2_centos ~]# yum -y install gcc zlib-devel pcre-devel openssl-devel\r\n    [root@VM_0_2_centos ~]# wget http://nginx.org/download/nginx-1.15.11.tar.gz\r\n    [root@VM_0_2_centos ~]# tar -xvf nginx-1.15.11.tar.gz\r\n    [root@VM_0_2_centos nginx-1.15.11]# useradd -s /sbin/nologin nginx\r\n    [root@VM_0_2_centos nginx-1.15.11]# ./configure --prefix=/usr/local/nginx --user=nginx \\\r\n    > --group=nginx --with-http_ssl_module with-http_stub_status_module --without-http_fastcgi_module --without-mail_pop3_module --without-mail_imap_module --without-mail_smtp_module\r\n    [root@VM_0_2_centos nginx-1.15.11]# make && make install\r\n    [root@VM_0_2_centos nginx-1.15.11]# cd\r\n    [root@VM_0_2_centos ~]# ln -s /usr/local/nginx/sbin/nginx /sbin/\r\n    [root@VM_0_2_centos ~]# vim /usr/local/nginx/conf/nginx.conf\r\n    #主要修改如下配置\r\n            location /static/ {\r\n                root   html;\r\n                #index  index.html index.htm;\r\n            }\r\n            location / {\r\n                include /usr/local/nginx/conf/uwsgi_params;\r\n                uwsgi_pass 127.0.0.1:9090;\r\n            }\r\n    [root@VM_0_2_centos ~]# nginx\r\n    [root@VM_0_2_centos ~]# ss -tunlp | grep :80\r\n    tcp    LISTEN     0      128       *:80                    *:*                   users:((\"nginx\",pid=11208,fd=6),(\"nginx\",pid=11207,fd=6))\r\n\r\n**三 mariadb数据库安装**\r\n\r\n    [root@VM_0_2_centos ~]# yum -y install mariadb mariadb-server mariadb-devel\r\n    [root@VM_0_2_centos ~]# vim /etc/my.cnf\r\n    character-set-server=utf8\r\n    [root@VM_0_2_centos ~]# systemctl restart mariadb\r\n    [root@VM_0_2_centos ~]# mysql -uroot\r\n    MariaDB [(none)]> CREATE DATABASE `djangoblog`;\r\n    MariaDB [(none)]> grant all on djangoblog.* to blog@localhost identified by \'password\';\r\n\r\n**四 python+uwsgi+django环境搭建**\r\n\r\n    [root@VM_0_2_centos ~]# yum -y install git\r\n    [root@VM_0_2_centos ~]# git clone https://github.com/luodidiao/DjangoBlog.git\r\n    [root@VM_0_2_centos ~]# wget https://www.python.org/ftp/python/3.5.2/Python-3.5.2.tgz\r\n    [root@VM_0_2_centos ~]#tar -zxvf Python-3.5.2.tgz\r\n    [root@VM_0_2_centos ~]#cd Python-3.5.2\r\n    [root@VM_0_2_centos ~]#./configure \r\n    [root@VM_0_2_centos ~]#make \r\n    [root@VM_0_2_centos ~]#make install\r\n    [root@VM_0_2_centos ~]#pip3 install virtualenv\r\n    [root@VM_0_2_centos ~]#cd ~ && mkdir ENV &&cd ENV\r\n    [root@VM_0_2_centos ENV]# virtualenv -p /usr/bin/python3 python3\r\n    [root@VM_0_2_centos ENV]# source python3/bin/activate\r\n    (python3) [root@VM_0_2_centos ENV]# pip3 install uwsgi\r\n    (python3) [root@VM_0_2_centos ~]# cd DjangoBlog/\r\n    (python3) [root@VM_0_2_centos DjangoBlog]# pip3 install -Ur requirements.txt\r\n    创建数据库\r\n    (python3) [root@VM_0_2_centos DjangoBlog]# ./manage.py makemigrations\r\n    (python3) [root@VM_0_2_centos DjangoBlog]# ./manage.py migrate\r\n    创建超级用户\r\n    (python3) [root@VM_0_2_centos DjangoBlog]#./manage.py createsuperuser\r\n    创建测试数据\r\n    (python3) [root@VM_0_2_centos DjangoBlog]#./manage.py create_testdata\r\n    收集静态文件\r\n    (python3) [root@VM_0_2_centos DjangoBlog]#./manage.py collectstatic --noinput\r\n    (python3) [root@VM_0_2_centos DjangoBlog]#./manage.py compress --force\r\n    开启uwsgi服务\r\n    (python3) [root@VM_0_2_centos DjangoBlog]# uwsgi --ini start_uwsgi.ini\r\n    (python3) [root@VM_0_2_centos DjangoBlog]# ss -tunlp | grep :9090\r\n    tcp    LISTEN     0      100    127.0.0.1:9090                  *:*                   users:((\"uwsgi\",pid=11154,fd=3),(\"uwsgi\",pid=11153,fd=3),(\"uwsgi\",pid=11151,fd=3))\r\n    浏览器打开: http://127.0.0.1 就可以看到效果了','2019-04-05 14:18:00.000000','p','o','a',268,0,1,23),(4,'2019-04-16 08:19:47.528318','2019-04-16 08:19:47.528340','nginx安装-yum版','`enter code here`**1，下载新的CentOS-Base.repo 到/etc/yum.repos.d/**\r\n\r\n    CentOS 6\r\n    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-6.repo\r\n    CentOS 7\r\n    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo\r\n    wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo\r\n\r\n**2，安装启动服务**\r\n\r\n    [root@VM_0_2_centos ~]# yum -y install nginx\r\n    [root@VM_0_2_centos ~]# systemctl restart nginx\r\n    [root@VM_0_2_centos ~]# ss -tunlp | grep :80\r\n    tcp    LISTEN     0      128       *:80                    *:*                   users:((\"nginx\",pid=11208,fd=6),(\"nginx\",pid=11207,fd=6))\r\n\r\n**3，测试**\r\n\r\n    [root@VM_0_2_centos ~]# curl http://127.0.0.1\r\n    或者\r\n    打开浏览器输入http://127.0.0.1即可查看','2019-04-16 08:19:00.000000','p','o','a',53,0,1,3),(5,'2019-04-16 08:25:15.776526','2019-04-16 08:25:15.776540','CentOS7.5安装搜狗输入法','**１，获取yum源**\r\n\r\n    下载阿里云的CentOS-Base.repo 到/etc/yum.repos.d/\r\n    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo\r\n    \r\n    或者\r\n    \r\n    curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo\r\n\r\n**２，安装软件包**\r\n\r\n    安装epel和依赖包\r\n    yum install epel-release -y\r\n    yum install alien -y\r\n    yum install qtwebkit -y\r\n    \r\n    转换deb包为rpm包\r\n    alien -r sogoupinyin_2.2.0.0108_amd64.deb\r\n    \r\n    删除ibus\r\n    yum erase ibus -y\r\n    pkill ibus-daemon\r\n    \r\n    安装fcitx\r\n    yum install fcitx fcitx-libs fcitx-pinyin fcitx-configtool -y\r\n    \r\n    这里有可能出现与文件系统冲突的问题,所以直接--force\r\n    rpm -ivh --force sogoupinyin-2.2.0.0108-2.x86_64.rpm\r\n    \r\n    切换输入法\r\n    imsettings-switch fcitx\r\n    fcitx -r; fcitx-configtool\r\n    sogou-qimpanel',NULL,'p','o','a',43,0,1,1);
/*!40000 ALTER TABLE `blog_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_article_tags`
--

DROP TABLE IF EXISTS `blog_article_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_article_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_article_tags_article_id_tag_id_b78a22e9_uniq` (`article_id`,`tag_id`),
  KEY `blog_article_tags_tag_id_88eb3ed9_fk_blog_tag_id` (`tag_id`),
  CONSTRAINT `blog_article_tags_article_id_82c02dd6_fk_blog_article_id` FOREIGN KEY (`article_id`) REFERENCES `blog_article` (`id`),
  CONSTRAINT `blog_article_tags_tag_id_88eb3ed9_fk_blog_tag_id` FOREIGN KEY (`tag_id`) REFERENCES `blog_tag` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_article_tags`
--

LOCK TABLES `blog_article_tags` WRITE;
/*!40000 ALTER TABLE `blog_article_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_article_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogsettings`
--

DROP TABLE IF EXISTS `blog_blogsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(200) NOT NULL,
  `site_description` longtext NOT NULL,
  `site_seo_description` longtext NOT NULL,
  `site_keywords` longtext NOT NULL,
  `article_sub_length` int(11) NOT NULL,
  `sidebar_article_count` int(11) NOT NULL,
  `sidebar_comment_count` int(11) NOT NULL,
  `show_google_adsense` tinyint(1) NOT NULL,
  `google_adsense_codes` longtext,
  `open_site_comment` tinyint(1) NOT NULL,
  `beiancode` varchar(2000) DEFAULT NULL,
  `analyticscode` longtext NOT NULL,
  `show_gongan_code` tinyint(1) NOT NULL,
  `gongan_beiancode` longtext,
  `resource_path` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogsettings`
--

LOCK TABLES `blog_blogsettings` WRITE;
/*!40000 ALTER TABLE `blog_blogsettings` DISABLE KEYS */;
INSERT INTO `blog_blogsettings` VALUES (1,'罗低调作品集','努力把自己变得更好，让不喜欢你的人喜欢你','罗低调作品集','Django,Python,linux,nginx,tomcat,zabbix,docker',300,10,5,0,'',1,NULL,'jluo',0,'','/var/www/resource/');
/*!40000 ALTER TABLE `blog_blogsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_category`
--

DROP TABLE IF EXISTS `blog_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `parent_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `blog_category_parent_category_id_f50c3c0c_fk_blog_category_id` (`parent_category_id`),
  KEY `blog_category_slug_92643dc5` (`slug`),
  CONSTRAINT `blog_category_parent_category_id_f50c3c0c_fk_blog_category_id` FOREIGN KEY (`parent_category_id`) REFERENCES `blog_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_category`
--

LOCK TABLES `blog_category` WRITE;
/*!40000 ALTER TABLE `blog_category` DISABLE KEYS */;
INSERT INTO `blog_category` VALUES (1,'2019-04-10 12:56:37.787629','2019-04-10 12:56:37.787640','linux','linux',NULL),(2,'2019-04-10 12:56:43.079946','2019-04-10 12:56:43.079957','web','web',NULL),(3,'2019-04-10 12:56:51.061832','2019-04-10 12:56:51.061842','nginx','nginx',2),(4,'2019-04-10 12:56:58.809388','2019-04-10 12:56:58.809400','tomcat','tomcat',2),(6,'2019-04-10 12:59:36.706682','2019-04-10 12:59:36.706694','数据库','shu-ju-ku',NULL),(7,'2019-04-10 13:00:27.363598','2019-04-10 13:00:27.363613','低调运维','di-diao-yun-wei',NULL),(8,'2019-04-10 13:00:57.364446','2019-04-10 13:00:57.364461','zabbix','zabbix',7),(9,'2019-04-10 13:01:16.676002','2019-04-10 13:01:16.676022','elk','elk',7),(10,'2019-04-10 13:01:26.466207','2019-04-10 13:01:26.466221','docker','docker',7),(11,'2019-04-10 13:02:10.533730','2019-04-10 13:02:10.533746','技能分享','ji-neng-fen-xiang',NULL),(12,'2019-04-10 13:03:18.963019','2019-04-10 13:03:18.963029','mysql','mysql',6),(13,'2019-04-10 13:03:27.167807','2019-04-10 13:03:27.167818','redis','redis',6),(14,'2019-04-10 13:03:43.878954','2019-04-10 13:03:43.878965','memcached','memcached',6),(19,'2019-04-10 13:12:20.666169','2019-04-10 13:12:20.666180','其他','qi-ta',7),(23,'2019-04-10 13:16:30.763801','2019-04-10 13:16:30.763813','myblog','myblog',11),(24,'2019-04-10 13:16:39.719382','2019-04-10 13:16:39.719396','project','project',11),(27,'2019-04-11 00:32:40.338307','2019-04-11 00:32:40.338318','随笔','sui-bi',NULL),(28,'2019-04-16 07:24:32.595493','2019-04-16 07:24:32.595505','network','network',NULL);
/*!40000 ALTER TABLE `blog_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_links`
--

DROP TABLE IF EXISTS `blog_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `link` varchar(200) NOT NULL,
  `sequence` int(11) NOT NULL,
  `is_enable` tinyint(1) NOT NULL,
  `show_type` varchar(1) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `sequence` (`sequence`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_links`
--

LOCK TABLES `blog_links` WRITE;
/*!40000 ALTER TABLE `blog_links` DISABLE KEYS */;
INSERT INTO `blog_links` VALUES (3,'w3cschool','https://www.w3cschool.cn/',0,1,'i','2019-04-12 06:31:04.164804','2019-04-12 06:31:04.164818'),(4,'gitbook','https://gitbook.lylinux.net/',1,1,'i','2019-04-12 06:45:44.348777','2019-04-12 06:45:44.348793');
/*!40000 ALTER TABLE `blog_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_sidebar`
--

DROP TABLE IF EXISTS `blog_sidebar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_sidebar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  `sequence` int(11) NOT NULL,
  `is_enable` tinyint(1) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sequence` (`sequence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_sidebar`
--

LOCK TABLES `blog_sidebar` WRITE;
/*!40000 ALTER TABLE `blog_sidebar` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_sidebar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `slug` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `blog_tag_slug_01068d0e` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tag`
--

LOCK TABLES `blog_tag` WRITE;
/*!40000 ALTER TABLE `blog_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments_comment`
--

DROP TABLE IF EXISTS `comments_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  `is_enable` tinyint(1) NOT NULL,
  `article_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_comment_article_id_94fe60a2_fk_blog_article_id` (`article_id`),
  KEY `comments_comment_author_id_334ce9e2_fk_accounts_bloguser_id` (`author_id`),
  KEY `comments_comment_parent_comment_id_71289d4a_fk_comments_` (`parent_comment_id`),
  CONSTRAINT `comments_comment_article_id_94fe60a2_fk_blog_article_id` FOREIGN KEY (`article_id`) REFERENCES `blog_article` (`id`),
  CONSTRAINT `comments_comment_author_id_334ce9e2_fk_accounts_bloguser_id` FOREIGN KEY (`author_id`) REFERENCES `accounts_bloguser` (`id`),
  CONSTRAINT `comments_comment_parent_comment_id_71289d4a_fk_comments_` FOREIGN KEY (`parent_comment_id`) REFERENCES `comments_comment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments_comment`
--

LOCK TABLES `comments_comment` WRITE;
/*!40000 ALTER TABLE `comments_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_accounts_bloguser_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_accounts_bloguser_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_bloguser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2019-04-10 12:50:31.363773','1','罗低调作品集',2,'[{\"changed\": {\"fields\": [\"sitename\", \"analyticscode\"]}}]',11,1),(2,'2019-04-10 12:53:36.926599','1','罗低调',2,'[{\"changed\": {\"fields\": [\"sitename\", \"site_description\", \"site_seo_description\", \"site_keywords\", \"analyticscode\"]}}]',11,1),(3,'2019-04-10 12:54:23.089252','1','低调blog',2,'[{\"changed\": {\"fields\": [\"sitename\"]}}]',11,1),(4,'2019-04-10 12:55:11.154752','1','罗低调作品集',2,'[{\"changed\": {\"fields\": [\"sitename\"]}}]',11,1),(5,'2019-04-10 12:56:37.970906','1','linux',1,'[{\"added\": {}}]',8,1),(6,'2019-04-10 12:56:43.284620','2','web',1,'[{\"added\": {}}]',8,1),(7,'2019-04-10 12:56:51.379973','3','nginx',1,'[{\"added\": {}}]',8,1),(8,'2019-04-10 12:56:58.995311','4','tomcat',1,'[{\"added\": {}}]',8,1),(9,'2019-04-10 12:57:51.203765','5','低调运维',1,'[{\"added\": {}}]',8,1),(10,'2019-04-10 12:58:25.673996','5','低调运维',3,'',8,1),(11,'2019-04-10 12:59:36.907453','6','数据库',1,'[{\"added\": {}}]',8,1),(12,'2019-04-10 13:00:27.595186','7','低调运维',1,'[{\"added\": {}}]',8,1),(13,'2019-04-10 13:00:57.550953','8','zabbix',1,'[{\"added\": {}}]',8,1),(14,'2019-04-10 13:01:16.954140','9','elk',1,'[{\"added\": {}}]',8,1),(15,'2019-04-10 13:01:26.653256','10','docker',1,'[{\"added\": {}}]',8,1),(16,'2019-04-10 13:02:10.948583','11','技能分享',1,'[{\"added\": {}}]',8,1),(17,'2019-04-10 13:03:19.145683','12','mysql',1,'[{\"added\": {}}]',8,1),(18,'2019-04-10 13:03:27.394997','13','redis',1,'[{\"added\": {}}]',8,1),(19,'2019-04-10 13:03:44.113969','14','memcached',1,'[{\"added\": {}}]',8,1),(20,'2019-04-10 13:05:12.275240','15','本站部署',1,'[{\"added\": {}}]',8,1),(21,'2019-04-10 13:05:19.522601','16','其他',1,'[{\"added\": {}}]',8,1),(22,'2019-04-10 13:05:53.145212','17','other',1,'[{\"added\": {}}]',8,1),(23,'2019-04-10 13:06:39.876813','17','other',3,'',8,1),(24,'2019-04-10 13:06:39.880641','15','本站部署',3,'',8,1),(25,'2019-04-10 13:08:17.311946','16','其他',3,'',8,1),(26,'2019-04-10 13:11:22.468318','18','本站部署',1,'[{\"added\": {}}]',8,1),(27,'2019-04-10 13:12:20.864335','19','其他',1,'[{\"added\": {}}]',8,1),(28,'2019-04-10 13:14:13.006076','18','本站部署',3,'',8,1),(29,'2019-04-10 13:14:40.693194','20','blog',1,'[{\"added\": {}}]',8,1),(30,'2019-04-10 13:14:49.565300','21','other',1,'[{\"added\": {}}]',8,1),(31,'2019-04-10 13:15:18.472376','22','project',1,'[{\"added\": {}}]',8,1),(32,'2019-04-10 13:16:01.248930','21','other',3,'',8,1),(33,'2019-04-10 13:16:01.253196','22','project',3,'',8,1),(34,'2019-04-10 13:16:21.686287','20','blog',3,'',8,1),(35,'2019-04-10 13:16:31.901666','23','myblog',1,'[{\"added\": {}}]',8,1),(36,'2019-04-10 13:16:40.212720','24','project',1,'[{\"added\": {}}]',8,1),(37,'2019-04-10 13:17:12.606004','25','其他分享',1,'[{\"added\": {}}]',8,1),(38,'2019-04-10 13:18:34.894379','25','其他分享',3,'',8,1),(39,'2019-04-10 13:43:12.529989','1','罗低调作品集',2,'[{\"changed\": {\"fields\": [\"site_description\"]}}]',11,1),(40,'2019-04-10 13:59:37.922281','2','',1,'[{\"added\": {}}]',13,1),(41,'2019-04-10 14:03:36.312334','1','rsync＋inotify实时数据同步',1,'[{\"added\": {}}]',7,1),(42,'2019-04-10 14:04:28.849431','2','',3,'',13,1),(43,'2019-04-10 14:05:54.521814','1','rsync＋inotify实时数据同步',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(44,'2019-04-10 14:06:33.405866','1','rsync＋inotify实时数据同步',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(45,'2019-04-10 14:07:49.301528','1','rsync＋inotify实时数据同步',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(46,'2019-04-10 14:14:41.665204','2','nginx性能优化--第一节',1,'[{\"added\": {}}]',7,1),(47,'2019-04-11 00:32:07.720198','26','ps',1,'[{\"added\": {}}]',8,1),(48,'2019-04-11 00:32:40.554086','27','随笔',1,'[{\"added\": {}}]',8,1),(49,'2019-04-11 00:32:58.851219','26','ps',3,'',8,1),(50,'2019-04-11 00:34:18.919207','1','罗低调作品集',2,'[{\"changed\": {\"fields\": [\"analyticscode\"]}}]',11,1),(51,'2019-04-11 14:18:50.706098','3','本站博客部署教程uwsgi+nginx-第一节',1,'[{\"added\": {}}]',7,1),(52,'2019-04-11 15:49:42.913638','3','本站博客部署教程uwsgi+nginx',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(53,'2019-04-12 01:31:43.680250','1','22',1,'[{\"added\": {}}]',10,1),(54,'2019-04-12 01:32:32.252258','1','22',3,'',10,1),(55,'2019-04-12 05:33:38.683178','2','罗低调',1,'[{\"added\": {}}]',10,1),(56,'2019-04-12 05:34:21.741236','2','罗低调',3,'',10,1),(57,'2019-04-12 06:31:04.168992','3','w3cschool',1,'[{\"added\": {}}]',10,1),(58,'2019-04-12 06:45:44.352901','4','gitbook',1,'[{\"added\": {}}]',10,1),(59,'2019-04-12 11:01:00.393825','2','',1,'[{\"added\": {}}]',13,1),(60,'2019-04-12 11:40:40.668167','1','473145009@qq.com',2,'[{\"changed\": {\"fields\": [\"password\", \"last_login\"]}}]',13,3),(61,'2019-04-12 11:41:08.413214','2','longchung@qq.com',2,'[{\"changed\": {\"fields\": [\"email\"]}}]',13,3),(62,'2019-04-15 00:55:54.135773','2','longchung@qq.com',3,'',13,3),(63,'2019-04-15 00:56:05.673776','1','473145009@qq.com',2,'[]',13,3),(64,'2019-04-15 02:28:22.876946','1','473145009@qq.com',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',13,3),(65,'2019-04-15 02:29:10.549217','1','473145009@qq.com',2,'[]',13,3),(66,'2019-04-16 07:24:32.833127','28','network',1,'[{\"added\": {}}]',8,3),(67,'2019-04-16 07:27:46.892404','1','473145009@qq.com',2,'[]',13,3),(68,'2019-04-16 07:29:53.101582','1','473145009@qq.com',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',13,3),(69,'2019-04-16 08:19:47.773488','4','nginx安装-yum板',1,'[{\"added\": {}}]',7,3),(70,'2019-04-16 08:20:55.364361','4','nginx安装-yum板',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,3),(71,'2019-04-16 08:21:22.280603','4','nginx安装-yum板',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,3),(72,'2019-04-16 08:25:16.010606','5','CentOS7.5安装搜狗输入法',1,'[{\"added\": {}}]',7,3),(73,'2019-04-16 08:26:15.677712','4','nginx安装-yum版',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,3),(74,'2019-04-16 08:29:12.940302','1','473145009@qq.com',2,'[{\"changed\": {\"fields\": [\"password\", \"username\"]}}]',13,3),(75,'2019-04-16 08:30:51.203757','29','赞助',1,'[{\"added\": {}}]',8,3),(76,'2019-04-16 08:37:03.174404','3','本站博客部署教程uwsgi+nginx',2,'[{\"changed\": {\"fields\": [\"article_order\"]}}]',7,3),(77,'2019-04-16 08:37:27.602228','2','nginx性能优化--第一节',2,'[{\"changed\": {\"fields\": [\"article_order\"]}}]',7,3),(78,'2019-04-16 08:42:22.521244','29','赞助',3,'',8,3),(79,'2019-04-16 08:45:06.957144','3','本站博客部署教程uwsgi+nginx',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,3);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (13,'accounts','bloguser'),(1,'admin','logentry'),(2,'auth','group'),(3,'auth','permission'),(7,'blog','article'),(11,'blog','blogsettings'),(8,'blog','category'),(10,'blog','links'),(12,'blog','sidebar'),(9,'blog','tag'),(14,'comments','comment'),(4,'contenttypes','contenttype'),(16,'oauth','oauthconfig'),(15,'oauth','oauthuser'),(19,'owntracks','owntracklog'),(17,'servermanager','commands'),(18,'servermanager','emailsendlog'),(5,'sessions','session'),(6,'sites','site');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-04-10 12:45:35.376901'),(2,'contenttypes','0002_remove_content_type_name','2019-04-10 12:45:35.467965'),(3,'auth','0001_initial','2019-04-10 12:45:35.697965'),(4,'auth','0002_alter_permission_name_max_length','2019-04-10 12:45:35.745463'),(5,'auth','0003_alter_user_email_max_length','2019-04-10 12:45:35.757317'),(6,'auth','0004_alter_user_username_opts','2019-04-10 12:45:35.772020'),(7,'auth','0005_alter_user_last_login_null','2019-04-10 12:45:35.786882'),(8,'auth','0006_require_contenttypes_0002','2019-04-10 12:45:35.792188'),(9,'auth','0007_alter_validators_add_error_messages','2019-04-10 12:45:35.806877'),(10,'auth','0008_alter_user_username_max_length','2019-04-10 12:45:35.820690'),(11,'auth','0009_alter_user_last_name_max_length','2019-04-10 12:45:35.833760'),(12,'accounts','0001_initial','2019-04-10 12:45:36.084121'),(13,'admin','0001_initial','2019-04-10 12:45:36.176034'),(14,'admin','0002_logentry_remove_auto_add','2019-04-10 12:45:36.198865'),(15,'admin','0003_logentry_add_action_flag_choices','2019-04-10 12:45:36.220714'),(16,'blog','0001_initial','2019-04-10 12:45:36.704019'),(17,'comments','0001_initial','2019-04-10 12:45:36.820811'),(18,'oauth','0001_initial','2019-04-10 12:45:36.919310'),(19,'owntracks','0001_initial','2019-04-10 12:45:36.950323'),(20,'servermanager','0001_initial','2019-04-10 12:45:36.995569'),(21,'sessions','0001_initial','2019-04-10 12:45:37.058116'),(22,'sites','0001_initial','2019-04-10 12:45:37.082990'),(23,'sites','0002_alter_domain_unique','2019-04-10 12:45:37.129869');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('362415a5i5hgyshn36smup2u7n43a4bb','NTYzMjRlZmM4NDI4ZmZkMTljYTM1ZTViZDQ5MGFmODIyODQ4MWFkMTp7Il9hdXRoX3VzZXJfaGFzaCI6ImYzM2YyZWRlZDFmYzYzYzc1NTIzN2RiNTVhYTI0YWYzMzE5ODM4ZWQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJhY2NvdW50cy51c2VyX2xvZ2luX2JhY2tlbmQuRW1haWxPclVzZXJuYW1lTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjMifQ==','2019-04-30 07:32:12.980941');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_site_domain_a2e37b91_uniq` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_oauthconfig`
--

DROP TABLE IF EXISTS `oauth_oauthconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_oauthconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `appkey` varchar(200) NOT NULL,
  `appsecret` varchar(200) NOT NULL,
  `callback_url` varchar(200) NOT NULL,
  `is_enable` tinyint(1) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_oauthconfig`
--

LOCK TABLES `oauth_oauthconfig` WRITE;
/*!40000 ALTER TABLE `oauth_oauthconfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_oauthconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_oauthuser`
--

DROP TABLE IF EXISTS `oauth_oauthuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_oauthuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) NOT NULL,
  `nikename` varchar(50) NOT NULL,
  `token` varchar(150) DEFAULT NULL,
  `picture` varchar(350) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `matedata` varchar(3000) DEFAULT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_oauthuser_author_id_a975bef0_fk_accounts_bloguser_id` (`author_id`),
  CONSTRAINT `oauth_oauthuser_author_id_a975bef0_fk_accounts_bloguser_id` FOREIGN KEY (`author_id`) REFERENCES `accounts_bloguser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_oauthuser`
--

LOCK TABLES `oauth_oauthuser` WRITE;
/*!40000 ALTER TABLE `oauth_oauthuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_oauthuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owntracks_owntracklog`
--

DROP TABLE IF EXISTS `owntracks_owntracklog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owntracks_owntracklog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` varchar(100) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `created_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owntracks_owntracklog`
--

LOCK TABLES `owntracks_owntracklog` WRITE;
/*!40000 ALTER TABLE `owntracks_owntracklog` DISABLE KEYS */;
/*!40000 ALTER TABLE `owntracks_owntracklog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servermanager_commands`
--

DROP TABLE IF EXISTS `servermanager_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servermanager_commands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) NOT NULL,
  `command` varchar(2000) NOT NULL,
  `describe` varchar(300) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `last_mod_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servermanager_commands`
--

LOCK TABLES `servermanager_commands` WRITE;
/*!40000 ALTER TABLE `servermanager_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `servermanager_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servermanager_emailsendlog`
--

DROP TABLE IF EXISTS `servermanager_emailsendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servermanager_emailsendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emailto` varchar(300) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `content` longtext NOT NULL,
  `send_result` tinyint(1) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servermanager_emailsendlog`
--

LOCK TABLES `servermanager_emailsendlog` WRITE;
/*!40000 ALTER TABLE `servermanager_emailsendlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `servermanager_emailsendlog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-17 14:28:51
